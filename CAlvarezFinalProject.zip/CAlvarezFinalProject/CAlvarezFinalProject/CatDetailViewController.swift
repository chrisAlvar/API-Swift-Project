//
//  CatDetailViewController.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/29/25.
//

import UIKit

// ViewController to display details of a selected cat
class CatDetailViewController: UIViewController {

    // This will hold the selected Cat object passed from the table view
    var cat: Cat?

    // Image view to show the cat's picture
    private let imageView = UIImageView()

    // Label to display the cat breed
    private let breedLabel = UILabel()

    // MARK: - Init for programmatic UI (when not using storyboard)
    init() {
        super.init(nibName: nil, bundle: nil)
    }

    // Required initializer when subclassing UIViewController
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

    // Called after the view has loaded
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground // Set default background
        setupLayout()      // Configure UI elements and constraints
        displayCatInfo()   // Load image and breed info
    }

    // Layout and constraints for image and label
    private func setupLayout() {
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit // Maintain image aspect ratio
        view.addSubview(imageView)

        breedLabel.translatesAutoresizingMaskIntoConstraints = false
        breedLabel.textAlignment = .center
        breedLabel.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        view.addSubview(breedLabel)

        // Layout constraints
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            imageView.heightAnchor.constraint(equalToConstant: 300),

            breedLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            breedLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    // Populate the view with image and breed text
    private func displayCatInfo() {
        guard let cat = cat else { return }

        // Load and display image from URL
        if let url = URL(string: cat.url) {
            URLSession.shared.dataTask(with: url) { data, _, _ in
                if let data = data {
                    DispatchQueue.main.async {
                        self.imageView.image = UIImage(data: data)
                    }
                }
            }.resume()
        }

        // Set the breed label (fallback to "Unknown Breed" if missing)
        breedLabel.text = cat.breeds.first?.name ?? "Unknown Breed"
    }
}

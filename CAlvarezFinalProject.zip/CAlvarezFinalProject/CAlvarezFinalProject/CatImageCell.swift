//
//  CatImageCell.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/29/25.
//

import UIKit

// Custom UITableViewCell to display a cat image
class CatImageCell: UITableViewCell {

    // UIImageView to show the cat picture
    private let catImageView = UIImageView()

    // Initializer for when cell is created in code
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        // Set image scaling to maintain aspect ratio
        catImageView.contentMode = .scaleAspectFit
        catImageView.translatesAutoresizingMaskIntoConstraints = false

        // Add the image view to the cell's contentView
        contentView.addSubview(catImageView)

        // Pin image view to all sides of the cell
        NSLayoutConstraint.activate([
            catImageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            catImageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            catImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            catImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor)
        ])
    }

    // Required initializer for loading from storyboard (not used here)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // Load and display image from a URL string
    func configure(with imageURL: String) {
        guard let url = URL(string: imageURL) else { return }

        // Start asynchronous image download
        URLSession.shared.dataTask(with: url) { data, _, error in
            // Check for successful download
            guard let data = data, error == nil else { return }

            // Update image on the main thread to reflect in UI
            DispatchQueue.main.async {
                self.catImageView.image = UIImage(data: data)
            }
        }.resume()
    }
}

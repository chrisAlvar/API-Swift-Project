//
//  CatViewController.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/28/25.
//

import UIKit

// MARK: - Model: represents a Cat returned by the API
struct Cat: Decodable {
    let url: String                   // URL string of the cat image
    let breeds: [Breed]               // Array of breed info (may be empty)

    struct Breed: Decodable {
        let name: String              // Name of the breed
    }
}

// MARK: - ViewController: displays a list of cat images in a table view
class CatViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // Data source array to hold Cat objects fetched from the API
    private var cats: [Cat] = []

    // Table view to display images
    private let tableView = UITableView()

    // Called after the view is loaded into memory
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Cats"                  // Set navigation bar title
        view.backgroundColor = .systemBackground

        setupTableView()                // Configure and add the table view
        fetchCatImages()                // Start network call to load cat data
    }

    // MARK: - UI Setup

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)                           // Add table view to the view hierarchy

        tableView.dataSource = self                          // Provide row count & cells
        tableView.delegate   = self                          // Handle row selection

        // Register our custom cell class for reuse
        tableView.register(CatImageCell.self, forCellReuseIdentifier: "CatCell")
        tableView.rowHeight = 300                            // Fixed height for each image row
        tableView.separatorStyle = .none                     // Remove default separators

        // Constrain tableView to fill the entire view
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: - Networking

    private func fetchCatImages() {
        // Endpoint that returns 10 random cats, only those with breed info
        let urlString = "https://api.thecatapi.com/v1/images/search?limit=10&has_breeds=1"
        guard let url = URL(string: urlString) else { return }

        // Build the request and attach API key header
        var request = URLRequest(url: url)
        request.setValue(
            "live_Ar3ozDwJrED7gH8PrjoqGSuH61eZn6cslEPYyKOrhlwZ5iO9QPL5uDyLUN0UXRg7",
            forHTTPHeaderField: "x-api-key"
        )

        // Perform async network call
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print("Request error: \(error)")  // Log any network error
                return
            }

            guard let data = data else {
                print("No data received")        // Log missing data
                return
            }

            do {
                // Decode JSON into array of Cat
                let result = try JSONDecoder().decode([Cat].self, from: data)
                // Filter out any entries without breed info
                let catsWithBreed = result.filter { !$0.breeds.isEmpty }

                // Update UI on main thread
                DispatchQueue.main.async {
                    self.cats = catsWithBreed
                    self.tableView.reloadData()
                }
            } catch {
                print("Decoding error: \(error)")   // Log JSON parsing errors
            }
        }.resume()
    }

    // MARK: - UITableViewDataSource

    // Number of cats fetched.
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cats.count
    }

    // Configure each cell: dequeue, then give it the image URL to load.
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Dequeue a CatImageCell
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CatCell",
                                                       for: indexPath) as? CatImageCell else {
            return UITableViewCell()
        }
        let cat = cats[indexPath.row]
        cell.configure(with: cat.url)  // Tell cell to load & display the image
        return cell
    }

    // MARK: - UITableViewDelegate

    // Handle user tapping a row: navigate to detail screen
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true) // Deselect for nice UI

        let selectedCat = cats[indexPath.row]
        let detailVC = CatDetailViewController()
        detailVC.cat = selectedCat                     // Pass the Cat object
        navigationController?.pushViewController(detailVC,
                                                 animated: true) // Push detail screen
    }
}

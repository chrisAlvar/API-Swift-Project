//
//  DogDetailViewController.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/29/25.
//

import UIKit

// This view controller shows the full image and breed name of the selected dog
class DogDetailViewController: UIViewController {

    // The dog object passed from the main list view
    var dog: Dog?

    // UI Elements
    private let imageView = UIImageView()
    private let breedLabel = UILabel()

    // Initializer used when creating the view controller programmatically
    init() {
        super.init(nibName: nil, bundle: nil)
    }

    // Required initializer for storyboard support (not used in this case)
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }

    // Runs after the view is loaded into memory
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground // Light/dark mode adaptive background
        setupLayout()       // Setup UI constraints
        displayDogInfo()    // Display image and breed
    }

    // MARK: - Setup layout constraints
    private func setupLayout() {
        // Configure the image view
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit // Maintain image aspect ratio
        view.addSubview(imageView)

        // Configure the label to display breed name
        breedLabel.translatesAutoresizingMaskIntoConstraints = false
        breedLabel.textAlignment = .center
        breedLabel.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        view.addSubview(breedLabel)

        // Layout constraints for image and label
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            imageView.heightAnchor.constraint(equalToConstant: 300),

            breedLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 20),
            breedLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    // MARK: - Load the image and breed name
    private func displayDogInfo() {
        guard let dog = dog else { return } // Make sure the dog object exists

        // Load and display the image from the URL
        if let url = URL(string: dog.url) {
            URLSession.shared.dataTask(with: url) { data, _, _ in
                if let data = data {
                    DispatchQueue.main.async {
                        self.imageView.image = UIImage(data: data)
                    }
                }
            }.resume()
        }

        // Display the breed name, or "Unknown Breed" if not available
        breedLabel.text = dog.breeds.first?.name ?? "Unknown Breed"
    }
}

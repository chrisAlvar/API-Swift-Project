//
//  DogImageCell.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/29/25.
//

import UIKit

// MARK: - Custom UITableViewCell for displaying a dog image
class DogImageCell: UITableViewCell {

    // Display the dog image
    private let petImageView = UIImageView()

    // Initializer when creating cell programmatically
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupLayout() // Setup layout and constraints
    }

    // Required initializer when loading from storyboard or nib
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupLayout()
    }

    // MARK: - Layout Configuration
    private func setupLayout() {
        // Allow Auto Layout
        petImageView.translatesAutoresizingMaskIntoConstraints = false

        // Scale image while maintaining aspect ratio
        petImageView.contentMode = .scaleAspectFit

        // Add the image view to the cell’s content view
        contentView.addSubview(petImageView)

        // Define Layout constraints
        NSLayoutConstraint.activate([
            petImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            petImageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
            petImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            petImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10)
        ])
    }

    // MARK: - Configure the cell with image URL
    func configure(with imageUrl: String) {
        // Make sure the string is a valid URL
        guard let url = URL(string: imageUrl) else { return }

        // Fetch image data asynchronously
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data {
                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.petImageView.image = UIImage(data: data)
                }
            }
        }.resume() // Start the network request
    }
}

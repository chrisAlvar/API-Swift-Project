//
//  DogViewController.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/28/25.
//

import UIKit

// MARK: - Dog Model conforming to Decodable to parse JSON data
struct Dog: Decodable {
    let url: String // The image URL
    let breeds: [Breed] // Array of breed details

    struct Breed: Decodable {
        let name: String // Breed name
    }
}

// MARK: - Main ViewController that displays list of dog images
class DogViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    private var dogs: [Dog] = [] // Data source for the table view

    private let tableView = UITableView() // The main table view

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Dogs"
        view.backgroundColor = .systemBackground

        setupTableView()
        fetchDogImages()
    }

    // MARK: - Setup the table view layout and behavior
    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        // Set table view data source and delegate to self
        tableView.dataSource = self
        tableView.delegate = self

        // Register a custom cell class
        tableView.register(DogImageCell.self, forCellReuseIdentifier: "DogCell")

        // Set fixed row height
        tableView.rowHeight = 300

        // Set up Auto Layout constraints
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: - Fetch dog images from API
    private func fetchDogImages() {
        // TheDogAPI endpoint with that only shows data with breed info
        let urlString = "https://api.thedogapi.com/v1/images/search?limit=10&has_breeds=1"
        guard let url = URL(string: urlString) else { return }

        // Create a request and add the API key in headers
        var request = URLRequest(url: url)
        request.setValue("live_3OCod3mpqrBqucjucmZubQdWUqx1npUhzlO1GmjL8ARcaqDfzvdRmgz1OeRKZDK3", forHTTPHeaderField: "x-api-key")

        // Send async network request
        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print("Request error: \(error)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                // Decode JSON data into Dog array
                let result = try JSONDecoder().decode([Dog].self, from: data)

                // Filter only dogs with a non-empty breed array
                let dogsWithBreed = result.filter { !$0.breeds.isEmpty }

                // Update UI on the main thread
                DispatchQueue.main.async {
                    self.dogs = dogsWithBreed
                    self.tableView.reloadData()
                }
            } catch {
                print("Decoding error: \(error)")
            }
        }.resume() // Start the task
    }

    // MARK: - UITableViewDataSource

    // Number of rows equals number of dogs
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dogs.count
    }

    // Configure each cell with a dog image URL
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "DogCell", for: indexPath) as? DogImageCell else {
            return UITableViewCell()
        }
        let dog = dogs[indexPath.row]
        cell.configure(with: dog.url)
        return cell
    }

    // MARK: - UITableViewDelegate

    // Handle cell tap to go to detail screen
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let selectedDog = dogs[indexPath.row]

        // Navigate to detail screen, passing the dog object
        let detailVC = DogDetailViewController()
        detailVC.dog = selectedDog
        navigationController?.pushViewController(detailVC, animated: true)
    }
}

//
//  MapViewController.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/29/25.
//

import UIKit
import MapKit
import CoreLocation

// This view controller displays a map and shows the user's current location
class MapViewController: UIViewController, CLLocationManagerDelegate {

    // The map view shown on screen
    private let mapView = MKMapView()

    // Manages location updates
    private let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Map"

        setupMapView() // Add map to the view and configure layout
        setupLocationManager() // Ask for location permission and start updating location
    }

    // Set up the map view and add it to the view controller's view
    private func setupMapView() {
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapView.showsUserLocation = true // Show the blue dot for user's location
        view.addSubview(mapView)

        // Use Auto Layout to pin the map view to all edges of the screen
        NSLayoutConstraint.activate([
            mapView.topAnchor.constraint(equalTo: view.topAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }

    // Configure the location manager
    private func setupLocationManager() {
        locationManager.delegate = self // Set delegate to receive updates
        locationManager.desiredAccuracy = kCLLocationAccuracyBest // Most accurate location
        locationManager.requestWhenInUseAuthorization() // Ask for permission when app is in use
        locationManager.startUpdatingLocation() // Start receiving location updates
    }

    // MARK: - CLLocationManagerDelegate

    // Called when a new location is available
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let userLocation = locations.last else { return } // Use the most recent location

        // Create a map region centered on the user's location
        let region = MKCoordinateRegion(center: userLocation.coordinate,
                                        latitudinalMeters: 1000, // Zoom level vertically
                                        longitudinalMeters: 1000) // Zoom level horizontally
        mapView.setRegion(region, animated: true) // Animate map to that region
    }

    // Called when there's an error getting location updates
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location error: \(error)") // Print the error for debugging
    }
}

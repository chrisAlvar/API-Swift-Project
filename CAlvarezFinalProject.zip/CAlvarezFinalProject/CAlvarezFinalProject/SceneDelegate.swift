//
//  SceneDelegate.swift
//  CAlvarezFinalProject
//
//  Created by Student on 4/28/25.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        // Create the main window
        window = UIWindow(windowScene: windowScene)

        // Create the Dog View Controller
        let dogVC = DogViewController()
        dogVC.title = "Dogs"
        dogVC.tabBarItem = UITabBarItem(title: "Dogs", image: UIImage(systemName: "dog"), tag: 0)

        // Create the Cat View Controller
        let catVC = CatViewController()
        catVC.title = "Cats"
        catVC.tabBarItem = UITabBarItem(title: "Cats", image: UIImage(systemName: "cat"), tag: 1)

        // Add each ViewController inside a Navigation Controller (optional but looks nicer)
        let dogNav = UINavigationController(rootViewController: dogVC)
        let catNav = UINavigationController(rootViewController: catVC)
        
        let mapVC = UINavigationController(rootViewController: MapViewController())
        mapVC.tabBarItem = UITabBarItem(title: "Map", image: UIImage(systemName: "map"), tag: 2)


        // Create the Tab Bar Controller
        let tabBarController = UITabBarController()
        tabBarController.viewControllers = [dogNav, catNav, mapVC]

        // Set the Tab Bar Controller as the root
        window?.rootViewController = tabBarController
        window?.makeKeyAndVisible()
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Called as the scene is being released by the system.
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Called when the scene moves from an inactive state to active.
    }

    func sceneWillResignActive(_ scene: UIScene) {
        // Called when the scene moves from an active state to inactive.
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Called as the scene transitions from background to foreground.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Called as the scene transitions from foreground to background.
    }
}
